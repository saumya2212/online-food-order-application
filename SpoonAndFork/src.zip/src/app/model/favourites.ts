export class Favourites{
    itemId:number|undefined;
    itemName:string|undefined;
    price:number|undefined;
    rating:number|undefined;
    url:string|undefined
}