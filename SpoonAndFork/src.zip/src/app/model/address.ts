export class Address {
    houseNo!: number;
    landmark!:string;
    street!:string;
    city!:string;
    pin!:number
}