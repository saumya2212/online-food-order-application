export class PaymentOrder {
    orderAmount: number|undefined;
    orderInfo: string|undefined;
    }