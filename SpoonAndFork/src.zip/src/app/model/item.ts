export class Item {
    itemId: number|undefined;
    itemName: string|undefined;
    itemPrice: number|undefined;
    itemRating: number|undefined;
    imageUrl: string|undefined;
    count: number|undefined;
    status: string|undefined;
    restName?:string|undefined;
}
  