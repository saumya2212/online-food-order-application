export class RazorpayResponse {
    razorpay_payment_id: string | undefined;
    razorpay_order_id: string | undefined;
    razorpay_signature: string | undefined;
  }
